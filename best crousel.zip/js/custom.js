$(document).ready(function(){
	"use strict"
	var containerheight = $('.ced-carousel-wrap .items').height();
	$('.ced-carousel-wrap').css('height', containerheight);
	cedcarousel();
	$(window).on('resize', function(){
		cedcarousel();
		OpacityConcept();
		Opacity();
		Opacitymobile;
	});
});




function cedcarousel(){
	$('.ced-prev').addClass('disable');
	var itemmobile = $('.ced-carousel-inner').attr('mobile');
	var itemsmallmobile = $('.ced-carousel-inner').attr('smallmobile');
	var windowwidth = $(window).width();
	if(windowwidth >= 992){
		Checkitem();
		var item = $('.ced-carousel-inner').attr('showitem');
		var width_of_item_in_view = windowwidth/item;
		var totalitem = $('.ced-carousel-inner').children().length;
		var width_of_item_wrapper = width_of_item_in_view * totalitem;


		$('.ced-carousel-wrap').css('width',windowwidth);
		$('.ced-carousel-inner').css('width',width_of_item_wrapper + 5);
		$('.ced-carousel-inner .items').css('width',width_of_item_in_view);
		
		var counter = 0;
	    $(".ced-carousel-inner .items").each(function(idx,obj)
	    {	var item = $('.ced-carousel-inner').attr('showitem');
	        counter++;
	        if(counter <= item )
	        {

	            $(obj).addClass('active');
	        }
	        //if(counter == item) counter = 0;
		})
		Opacity();


		var leftposition = 0;
		var active_items = $('.ced-carousel-inner .items.active').length;
		//var totalitem1 = $('.ced-carousel-inner .items').length;
		var campi = 0;
		campi = active_items;

		$('.ced-next').on('click', function(e){	
		
			 var item = $('.ced-carousel-inner').attr('showitem');
			 var windowwidth = $(window).width();
			 var width_of_item_in_view = windowwidth/item;
			 //alert(width_of_item_in_view);
			 leftposition = leftposition - width_of_item_in_view;

			 //alert(leftposition);
			 $('.ced-carousel-inner').css('left', leftposition);

			 $('.ced-carousel-inner .items.active').first().removeClass('active');
			 $('.ced-carousel-inner .items.active').last().next().addClass('active');
			 OpacityConcept();
			 Opacity();
			campi+=1;
			if(campi < totalitem){
				$('.ced-prev').removeClass('disable');
			}
			if(campi == totalitem){
			  	//alert('this is now last item in list ' +campi);
			  	$(this).addClass('disable');
			}

		});
		$('.ced-prev').on('click', function(){
			var item = $('.ced-carousel-inner').attr('showitem');
			 var windowwidth = $(window).width();
			 var width_of_item_in_view = windowwidth/item;
			 leftposition = leftposition + width_of_item_in_view;
			 $('.ced-carousel-inner').css('left', leftposition);

			 $('.ced-carousel-inner .items.active').last().removeClass('active');
			 $('.ced-carousel-inner .items.active').first().prev().addClass('active');

			 OpacityConcept();
			 Opacity();

			campi-=1;
			
			if(campi < totalitem){
			  	//alert('this is now first item in list ' +campi);
			  	$('.ced-next').removeClass('disable');
			}
			if(campi == active_items){
			  	//alert('this is now first item in list ' +campi);
			  	$(this).addClass('disable');
			}
			//alert(campi);
		});


	}

	if(windowwidth < 992 && windowwidth > 768){
		Checkitem();
		var itemtab = $('.ced-carousel-inner').attr('tab');
		//alert(itemtab);
		var width_of_item_in_view = windowwidth/itemtab;
		var totalitem = $('.ced-carousel-inner').children().length;
		var width_of_item_wrapper = width_of_item_in_view * totalitem;


		$('.ced-carousel-wrap').css('width',windowwidth);
		$('.ced-carousel-inner').css('width',width_of_item_wrapper + 5);
		$('.ced-carousel-inner .items').css('width',width_of_item_in_view);
		
		var counter = 0;
	    $(".ced-carousel-inner .items").each(function(idx,obj)
	    {	var itemtab = $('.ced-carousel-inner').attr('tab');
	        counter++;
	        if(counter <= itemtab )
	        {

	            $(obj).addClass('active');
	        }
	        //if(counter == item) counter = 0;
		})
		Opacity();
	
		var leftposition = 0;
		var active_items = $('.ced-carousel-inner .items.active').length;
		//var totalitem1 = $('.ced-carousel-inner .items').length;
		var campi = 0;
		campi = active_items;

		$('.ced-next').on('click', function(e){	
			 var item = $('.ced-carousel-inner').attr('tab');
			 var windowwidth = $(window).width();
			 var width_of_item_in_view = windowwidth/item;
			 //alert(width_of_item_in_view);
			 leftposition = leftposition - width_of_item_in_view;

			 //alert(leftposition);
			 $('.ced-carousel-inner').css('left', leftposition);

			 $('.ced-carousel-inner .items.active').first().removeClass('active');
			 $('.ced-carousel-inner .items.active').last().next().addClass('active');
			 OpacityConcept();
			 Opacity();
			campi+=1;
			if(campi < totalitem){
				$('.ced-prev').removeClass('disable');
			}
			if(campi == totalitem){
			  	//alert('this is now last item in list ' +campi);
			  	$(this).addClass('disable');
			}
		});
		$('.ced-prev').on('click', function(){
			var item = $('.ced-carousel-inner').attr('tab');
			 var windowwidth = $(window).width();
			 var width_of_item_in_view = windowwidth/item;
			 leftposition = leftposition + width_of_item_in_view;
			 $('.ced-carousel-inner').css('left', leftposition);

			 $('.ced-carousel-inner .items.active').last().removeClass('active');
			 $('.ced-carousel-inner .items.active').first().prev().addClass('active');

			 OpacityConcept();
			 Opacity();

			campi-=1;
			
			if(campi < totalitem){
			  	//alert('this is now first item in list ' +campi);
			  	$('.ced-next').removeClass('disable');
			}
			if(campi == active_items){
			  	//alert('this is now first item in list ' +campi);
			  	$(this).addClass('disable');
			}
			//alert(campi);
		});
	}
	if(windowwidth <= 768 && windowwidth > 400){
		Checkitem();
		var itemmobile = $('.ced-carousel-inner').attr('mobile');
		//alert(itemmobile);
		var width_of_item_in_view = windowwidth/itemmobile;
		var totalitem = $('.ced-carousel-inner').children().length;
		var width_of_item_wrapper = width_of_item_in_view * totalitem;


		$('.ced-carousel-wrap').css('width',windowwidth);
		$('.ced-carousel-inner').css('width',width_of_item_wrapper + 5);
		$('.ced-carousel-inner .items').css('width',width_of_item_in_view);
		
		var counter = 0;
	    $(".ced-carousel-inner .items").each(function(idx,obj)
	    {	var itemmobile = $('.ced-carousel-inner').attr('mobile');
	        counter++;
	        if(counter <= itemmobile )
	        {

	            $(obj).addClass('active');
	        }
	        //if(counter == item) counter = 0;
		})
		Opacitymobile();
	
		var leftposition = 0;
		var active_items = $('.ced-carousel-inner .items.active').length;
		//var totalitem1 = $('.ced-carousel-inner .items').length;
		var campi = 0;
		campi = active_items;

		$('.ced-next').on('click', function(e){	
			 var item = $('.ced-carousel-inner').attr('mobile');
			 var windowwidth = $(window).width();
			 var width_of_item_in_view = windowwidth/item;
			 //alert(width_of_item_in_view);
			 leftposition = leftposition - width_of_item_in_view;

			 //alert(leftposition);
			 $('.ced-carousel-inner').css('left', leftposition);

			 $('.ced-carousel-inner .items.active').first().removeClass('active');
			 $('.ced-carousel-inner .items.active').last().next().addClass('active');
			 OpacityConcept();
			 Opacitymobile();
			campi+=1;
			if(campi < totalitem){
				$('.ced-prev').removeClass('disable');
			}
			if(campi == totalitem){
			  	//alert('this is now last item in list ' +campi);
			  	$(this).addClass('disable');
			}

		});
		$('.ced-prev').on('click', function(){
			var item = $('.ced-carousel-inner').attr('mobile');
			 var windowwidth = $(window).width();
			 var width_of_item_in_view = windowwidth/item;
			 leftposition = leftposition + width_of_item_in_view;
			 $('.ced-carousel-inner').css('left', leftposition);

			 $('.ced-carousel-inner .items.active').last().removeClass('active');
			 $('.ced-carousel-inner .items.active').first().prev().addClass('active');

			 OpacityConcept();
			 Opacitymobile();

			campi-=1;
			
			if(campi < totalitem){
			  	//alert('this is now first item in list ' +campi);
			  	$('.ced-next').removeClass('disable');
			}
			if(campi == active_items){
			  //	alert('this is now first item in list ' +campi);
			  	$(this).addClass('disable');
			}
			//alert(campi);
		});
	}

	if(windowwidth <= 400){
		Checkitem();
		var itemsmallmobile = $('.ced-carousel-inner').attr('smallmobile');
		//alert(itemmobile);
		var width_of_item_in_view = windowwidth/itemsmallmobile;
		var totalitem = $('.ced-carousel-inner').children().length;
		var width_of_item_wrapper = width_of_item_in_view * totalitem;


		$('.ced-carousel-wrap').css('width',windowwidth);
		$('.ced-carousel-inner').css('width',width_of_item_wrapper + 5);
		$('.ced-carousel-inner .items').css('width',width_of_item_in_view);
		
		var counter = 0;
	    $(".ced-carousel-inner .items").each(function(idx,obj)
	    {	var itemsmallmobile = $('.ced-carousel-inner').attr('smallmobile');
	        counter++;
	        if(counter <= itemsmallmobile )
	        {

	            $(obj).addClass('active');
	        }
	        //if(counter == item) counter = 0;
		})
		//Opacitymobile();
	
		var leftposition = 0;
		var active_items = $('.ced-carousel-inner .items.active').length;
		//var totalitem1 = $('.ced-carousel-inner .items').length;
		var campi = 0;
		campi = active_items;

		$('.ced-next').on('click', function(e){	
			 var item = $('.ced-carousel-inner').attr('smallmobile');
			 var windowwidth = $(window).width();
			 var width_of_item_in_view = windowwidth/item;
			 //alert(width_of_item_in_view);
			 leftposition = leftposition - width_of_item_in_view;

			 //alert(leftposition);
			 $('.ced-carousel-inner').css('left', leftposition);

			 //$('.ced-carousel-inner .items.active').first().removeClass('active');
			 $('.ced-carousel-inner .items.active').last().next().addClass('active');
			 //OpacityConcept();
			 //Opacitymobile();
			campi+=1;
			if(campi < totalitem){
				$('.ced-prev').removeClass('disable');
			}
			if(campi == totalitem){
			  	//alert('this is now last item in list ' +campi);
			  	$(this).addClass('disable');
			}
		});
		$('.ced-prev').on('click', function(){
			var item = $('.ced-carousel-inner').attr('smallmobile');
			 var windowwidth = $(window).width();
			 var width_of_item_in_view = windowwidth/item;
			 leftposition = leftposition + width_of_item_in_view;
			 $('.ced-carousel-inner').css('left', leftposition);

			 $('.ced-carousel-inner .items.active').last().removeClass('active');
			 $('.ced-carousel-inner .items.active').first().prev().addClass('active');

			 //OpacityConcept();
			 //Opacitymobile();

			campi-=1;
			
			if(campi < totalitem){
			  	//alert('this is now first item in list ' +campi);
			  	$('.ced-next').removeClass('disable');
			}
			if(campi == active_items){
			  //	alert('this is now first item in list ' +campi);
			  	$(this).addClass('disable');
			}
			//alert(campi);
		});
	}
}


function cedcarouselRTL(){
	$('.ced-prev').addClass('disable');
	var itemmobile = $('.ced-carousel-inner').attr('mobile');
	var itemsmallmobile = $('.ced-carousel-inner').attr('smallmobile');
	var windowwidth = $(window).width();
	if(windowwidth >= 992){
		Checkitem();
		var item = $('.ced-carousel-inner').attr('showitem');
		var width_of_item_in_view = windowwidth/item;
		var totalitem = $('.ced-carousel-inner').children().length;
		var width_of_item_wrapper = width_of_item_in_view * totalitem;


		$('.ced-carousel-wrap').css('width',windowwidth);
		$('.ced-carousel-inner').css('width',width_of_item_wrapper + 5);
		$('.ced-carousel-inner .items').css('width',width_of_item_in_view);
		
		var counter = 0;
	    $(".ced-carousel-inner .items").each(function(idx,obj)
	    {	var item = $('.ced-carousel-inner').attr('showitem');
	        counter++;
	        if(counter <= item )
	        {

	            $(obj).addClass('active');
	        }
	        //if(counter == item) counter = 0;
		})
		Opacity();


		var leftposition = 0;
		var active_items = $('.ced-carousel-inner .items.active').length;
		//var totalitem1 = $('.ced-carousel-inner .items').length;
		var campi = 0;
		campi = active_items;

		$('.ced-next').on('click', function(e){	
		
			 var item = $('.ced-carousel-inner').attr('showitem');
			 var windowwidth = $(window).width();
			 var width_of_item_in_view = windowwidth/item;
			 //alert(width_of_item_in_view);
			 leftposition = leftposition - width_of_item_in_view;

			 //alert(leftposition);
			 $('.ced-carousel-inner').css('left', leftposition);

			 $('.ced-carousel-inner .items.active').first().removeClass('active');
			 $('.ced-carousel-inner .items.active').last().next().addClass('active');
			 OpacityConcept();
			 Opacity();
			campi+=1;
			if(campi < totalitem){
				$('.ced-prev').removeClass('disable');
			}
			if(campi == totalitem){
			  	//alert('this is now last item in list ' +campi);
			  	$(this).addClass('disable');
			}

		});
		$('.ced-prev').on('click', function(){
			var item = $('.ced-carousel-inner').attr('showitem');
			 var windowwidth = $(window).width();
			 var width_of_item_in_view = windowwidth/item;
			 leftposition = leftposition + width_of_item_in_view;
			 $('.ced-carousel-inner').css('left', leftposition);

			 $('.ced-carousel-inner .items.active').last().removeClass('active');
			 $('.ced-carousel-inner .items.active').first().prev().addClass('active');

			 OpacityConcept();
			 Opacity();

			campi-=1;
			
			if(campi < totalitem){
			  	//alert('this is now first item in list ' +campi);
			  	$('.ced-next').removeClass('disable');
			}
			if(campi == active_items){
			  	//alert('this is now first item in list ' +campi);
			  	$(this).addClass('disable');
			}
			//alert(campi);
		});


	}

	if(windowwidth < 992 && windowwidth > 768){
		Checkitem();
		var itemtab = $('.ced-carousel-inner').attr('tab');
		//alert(itemtab);
		var width_of_item_in_view = windowwidth/itemtab;
		var totalitem = $('.ced-carousel-inner').children().length;
		var width_of_item_wrapper = width_of_item_in_view * totalitem;


		$('.ced-carousel-wrap').css('width',windowwidth);
		$('.ced-carousel-inner').css('width',width_of_item_wrapper + 5);
		$('.ced-carousel-inner .items').css('width',width_of_item_in_view);
		
		var counter = 0;
	    $(".ced-carousel-inner .items").each(function(idx,obj)
	    {	var itemtab = $('.ced-carousel-inner').attr('tab');
	        counter++;
	        if(counter <= itemtab )
	        {

	            $(obj).addClass('active');
	        }
	        //if(counter == item) counter = 0;
		})
		Opacity();
	
		var leftposition = 0;
		var active_items = $('.ced-carousel-inner .items.active').length;
		//var totalitem1 = $('.ced-carousel-inner .items').length;
		var campi = 0;
		campi = active_items;

		$('.ced-next').on('click', function(e){	
			 var item = $('.ced-carousel-inner').attr('tab');
			 var windowwidth = $(window).width();
			 var width_of_item_in_view = windowwidth/item;
			 //alert(width_of_item_in_view);
			 leftposition = leftposition - width_of_item_in_view;

			 //alert(leftposition);
			 $('.ced-carousel-inner').css('left', leftposition);

			 $('.ced-carousel-inner .items.active').first().removeClass('active');
			 $('.ced-carousel-inner .items.active').last().next().addClass('active');
			 OpacityConcept();
			 Opacity();
			campi+=1;
			if(campi < totalitem){
				$('.ced-prev').removeClass('disable');
			}
			if(campi == totalitem){
			  	//alert('this is now last item in list ' +campi);
			  	$(this).addClass('disable');
			}
		});
		$('.ced-prev').on('click', function(){
			var item = $('.ced-carousel-inner').attr('tab');
			 var windowwidth = $(window).width();
			 var width_of_item_in_view = windowwidth/item;
			 leftposition = leftposition + width_of_item_in_view;
			 $('.ced-carousel-inner').css('left', leftposition);

			 $('.ced-carousel-inner .items.active').last().removeClass('active');
			 $('.ced-carousel-inner .items.active').first().prev().addClass('active');

			 OpacityConcept();
			 Opacity();

			campi-=1;
			
			if(campi < totalitem){
			  	//alert('this is now first item in list ' +campi);
			  	$('.ced-next').removeClass('disable');
			}
			if(campi == active_items){
			  	//alert('this is now first item in list ' +campi);
			  	$(this).addClass('disable');
			}
			//alert(campi);
		});
	}
	if(windowwidth <= 768 && windowwidth > 400){
		Checkitem();
		var itemmobile = $('.ced-carousel-inner').attr('mobile');
		//alert(itemmobile);
		var width_of_item_in_view = windowwidth/itemmobile;
		var totalitem = $('.ced-carousel-inner').children().length;
		var width_of_item_wrapper = width_of_item_in_view * totalitem;


		$('.ced-carousel-wrap').css('width',windowwidth);
		$('.ced-carousel-inner').css('width',width_of_item_wrapper + 5);
		$('.ced-carousel-inner .items').css('width',width_of_item_in_view);
		
		var counter = 0;
	    $(".ced-carousel-inner .items").each(function(idx,obj)
	    {	var itemmobile = $('.ced-carousel-inner').attr('mobile');
	        counter++;
	        if(counter <= itemmobile )
	        {

	            $(obj).addClass('active');
	        }
	        //if(counter == item) counter = 0;
		})
		Opacitymobile();
	
		var leftposition = 0;
		var active_items = $('.ced-carousel-inner .items.active').length;
		//var totalitem1 = $('.ced-carousel-inner .items').length;
		var campi = 0;
		campi = active_items;

		$('.ced-next').on('click', function(e){	
			 var item = $('.ced-carousel-inner').attr('mobile');
			 var windowwidth = $(window).width();
			 var width_of_item_in_view = windowwidth/item;
			 //alert(width_of_item_in_view);
			 leftposition = leftposition - width_of_item_in_view;

			 //alert(leftposition);
			 $('.ced-carousel-inner').css('left', leftposition);

			 $('.ced-carousel-inner .items.active').first().removeClass('active');
			 $('.ced-carousel-inner .items.active').last().next().addClass('active');
			 OpacityConcept();
			 Opacitymobile();
			campi+=1;
			if(campi < totalitem){
				$('.ced-prev').removeClass('disable');
			}
			if(campi == totalitem){
			  	//alert('this is now last item in list ' +campi);
			  	$(this).addClass('disable');
			}

		});
		$('.ced-prev').on('click', function(){
			var item = $('.ced-carousel-inner').attr('mobile');
			 var windowwidth = $(window).width();
			 var width_of_item_in_view = windowwidth/item;
			 leftposition = leftposition + width_of_item_in_view;
			 $('.ced-carousel-inner').css('left', leftposition);

			 $('.ced-carousel-inner .items.active').last().removeClass('active');
			 $('.ced-carousel-inner .items.active').first().prev().addClass('active');

			 OpacityConcept();
			 Opacitymobile();

			campi-=1;
			
			if(campi < totalitem){
			  	//alert('this is now first item in list ' +campi);
			  	$('.ced-next').removeClass('disable');
			}
			if(campi == active_items){
			  //	alert('this is now first item in list ' +campi);
			  	$(this).addClass('disable');
			}
			//alert(campi);
		});
	}

	if(windowwidth <= 400){
		Checkitem();
		var itemsmallmobile = $('.ced-carousel-inner').attr('smallmobile');
		//alert(itemmobile);
		var width_of_item_in_view = windowwidth/itemsmallmobile;
		var totalitem = $('.ced-carousel-inner').children().length;
		var width_of_item_wrapper = width_of_item_in_view * totalitem;


		$('.ced-carousel-wrap').css('width',windowwidth);
		$('.ced-carousel-inner').css('width',width_of_item_wrapper + 5);
		$('.ced-carousel-inner .items').css('width',width_of_item_in_view);
		
		var counter = 0;
	    $(".ced-carousel-inner .items").each(function(idx,obj)
	    {	var itemsmallmobile = $('.ced-carousel-inner').attr('smallmobile');
	        counter++;
	        if(counter <= itemsmallmobile )
	        {

	            $(obj).addClass('active');
	        }
	        //if(counter == item) counter = 0;
		})
		//Opacitymobile();
	
		var leftposition = 0;
		var active_items = $('.ced-carousel-inner .items.active').length;
		//var totalitem1 = $('.ced-carousel-inner .items').length;
		var campi = 0;
		campi = active_items;

		$('.ced-next').on('click', function(e){	
			 var item = $('.ced-carousel-inner').attr('smallmobile');
			 var windowwidth = $(window).width();
			 var width_of_item_in_view = windowwidth/item;
			 //alert(width_of_item_in_view);
			 leftposition = leftposition - width_of_item_in_view;

			 //alert(leftposition);
			 $('.ced-carousel-inner').css('left', leftposition);

			 //$('.ced-carousel-inner .items.active').first().removeClass('active');
			 $('.ced-carousel-inner .items.active').last().next().addClass('active');
			 //OpacityConcept();
			 //Opacitymobile();
			campi+=1;
			if(campi < totalitem){
				$('.ced-prev').removeClass('disable');
			}
			if(campi == totalitem){
			  	//alert('this is now last item in list ' +campi);
			  	$(this).addClass('disable');
			}
		});
		$('.ced-prev').on('click', function(){
			var item = $('.ced-carousel-inner').attr('smallmobile');
			 var windowwidth = $(window).width();
			 var width_of_item_in_view = windowwidth/item;
			 leftposition = leftposition + width_of_item_in_view;
			 $('.ced-carousel-inner').css('left', leftposition);

			 $('.ced-carousel-inner .items.active').last().removeClass('active');
			 $('.ced-carousel-inner .items.active').first().prev().addClass('active');

			 //OpacityConcept();
			 //Opacitymobile();

			campi-=1;
			
			if(campi < totalitem){
			  	//alert('this is now first item in list ' +campi);
			  	$('.ced-next').removeClass('disable');
			}
			if(campi == active_items){
			  //	alert('this is now first item in list ' +campi);
			  	$(this).addClass('disable');
			}
			//alert(campi);
		});
	}
}




function OpacityConcept(){
	if($('.ced-carousel-inner .items').not('active')){
	 	$('.ced-carousel-inner .items').removeClass('opacity');
	 }
}
function Opacity(){
	var activeitem = $(".ced-carousel-inner .items.active").length;
	$('.ced-carousel-inner .items.active').slice( 0,2 ).addClass('opacity');
	$('.ced-carousel-inner .items.active').slice( activeitem-2 , activeitem ).addClass('opacity');
	//alert(activeitem);
}

function Opacitymobile(){
	var activeitem = $(".ced-carousel-inner .items.active").length;
	$('.ced-carousel-inner .items.active').slice( 0,1 ).addClass('opacity');
	$('.ced-carousel-inner .items.active').slice( activeitem-1 , activeitem ).addClass('opacity');
	//alert(activeitem);
}

function Checkitem(){
	var totalitem = $('.ced-carousel-inner').children().length;
	var itemmobile1 = $('.ced-carousel-inner').attr('mobile');
	var itemsmallmobile1 = $('.ced-carousel-inner').attr('smallmobile');
	var destop1 = $('.ced-carousel-inner').attr('showitem');
	var tab1 = $('.ced-carousel-inner').attr('tab');
	if(totalitem == destop1){
		$('.ced-next').addClass('disable');
	}
	if(totalitem == tab1){
		$('.ced-next').addClass('disable');
	}
	if(totalitem == itemsmallmobile1){
		$('.ced-next').addClass('disable');
	}
	if(totalitem == itemsmallmobile1){
		$('.ced-next').addClass('disable');
	}
}
